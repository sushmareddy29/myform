import React from 'react';
import {Input} from 'semantic-ui-react';
import './StepOne.css';
import {connect} from 'react-redux';
import {reduxForm, Field, formValues} from 'redux-form';
import StepOneForm from "./StepOneForm";
import {validate} from "./StepOneForm";


class StepOne extends React.Component {
    constructor(props) {
        super(props);
        this.isValidated = this.isValidated.bind(this);
    }

    isValidated() {
        debugger;
        const {stepOneFormValues} = this.props;
        console.log(this.props.stepOneFormValues);
        if(stepOneFormValues) {
           const errors = validate(stepOneFormValues.values);
           debugger;
           if(errors.noValues) {
               return false;
           } else if(errors.firstname || errors.email || errors.lastName ||errors.year) {
               return false
           }
        }
    }

    render() {
        return (
            <div className="StepOne">
                <StepOneForm />
            </div>
        );
    }

}

export default StepOne;
