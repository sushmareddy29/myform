import React from 'react';
import {Input} from 'semantic-ui-react';
import './StepOne.css';
import {connect} from 'react-redux';
import {reduxForm, Field, formValues} from 'redux-form';

export const validate = values => {
    const errors = {};
    debugger;
    if(!values) {
        errors.noValues = 'true';
    }
    else{
        if (!values.firstname) {
            errors.firstname = 'FirstName is required'
        }
        if (!values.lastName) {
            errors.lastName = 'Please Enter Last Name'
        }else if (values && values.lastName.length < 1) {
            errors.email = 'Please Enter Last Name'
        }
        if (!values.email) {
            errors.email = 'Please enter Email Address'
        }else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)) {
            errors.email = 'Invalid email address'
        }
        if (values.year && values.year.length<2) {
            errors.year = 'Please enter atleast 2 digits'
        }
    }

    return errors;
};

class StepOneForm extends React.Component {

    render() {
        const {stepOneForm} = this.props;
        return (
            <div className="StepOne">
                <div className='input-form-field'>
                    <Field name='firstname' component={"input"}/>
                    {(stepOneForm && stepOneForm.syncErrors && stepOneForm.syncErrors.firstname) &&
                    <p className={'input-form-validation'}>{stepOneForm.syncErrors.firstname}</p>}
                </div>
                <div className={'input-form-field'}>
                    <Field name='lastName' component={"input"}/>
                    {(stepOneForm && stepOneForm.syncErrors && stepOneForm.syncErrors.lastName) &&
                    <p className={'input-form-validation'}>{stepOneForm.syncErrors.lastName}</p>}
                </div>
                <div className={'input-form-field'}>
                    <Field name='email' component={"input"}/>
                    {(stepOneForm && stepOneForm.syncErrors && stepOneForm.syncErrors.email) &&
                    <p className={'input-form-validation'}>{stepOneForm.syncErrors.email}</p>}
                </div>
                <div className={'input-form-field'}>
                    <Field name='year' component={"input"}/>
                    {(stepOneForm && stepOneForm.syncErrors && stepOneForm.syncErrors.year) &&
                    <p className={'input-form-validation'}>{stepOneForm.syncErrors.year}</p>}
                </div>
            </div>
        );
    }

}
const mapStateToProps = ( state ) => {
    return {
        stepOneForm: ( state.form.stepOneForm )
    };
}

StepOneForm = reduxForm({
    form: 'stepOneForm',
    validate,
    destroyOnUnmount: false
})(connect(mapStateToProps, null)(StepOneForm));

export default StepOneForm;
