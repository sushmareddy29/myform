import React from 'react';
import StepZilla from "react-stepzilla";
import StepOne from '../StepOne/StepOne';
import StepTwo from '../StepTwo/StepTwo';
import StepThree from '../StepThree/StepThree';
import {connect} from 'react-redux';

class Home extends React.Component {
    render() {
        const steps = [
            {name: 'Step 1', component: <StepOne stepOneFormValues={this.props.stepOneForm}/>},
            {name: 'StepTwo', component: <StepTwo/>},
            {name: 'StepThree', component: <StepThree/>}

        ];
        return (
                <div className="App">
                    <form>
                        <StepZilla showNavigation showSteps steps={steps}/>
                    </form>
                </div>
        );
    }

}

const mapStateToProps = ( state ) => {
    return {
        stepOneForm: ( state.form.stepOneForm )
    };
}

export default connect(mapStateToProps, null)(Home);
